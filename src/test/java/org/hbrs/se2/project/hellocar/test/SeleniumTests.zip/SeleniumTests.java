package org.hbrs.se2.project.hellocar.test;

import org.hbrs.se2.project.hellocar.HellocarApplication;
import org.hbrs.se2.project.hellocar.control.ManageUserControl;
import org.hbrs.se2.project.hellocar.control.builders.CompanyDTOBuilder;
import org.hbrs.se2.project.hellocar.control.builders.StudentDTOBuilder;
import org.hbrs.se2.project.hellocar.control.exception.DatabaseUserException;
import org.hbrs.se2.project.hellocar.dtos.impl.account.CompanyDTOImpl;
import org.hbrs.se2.project.hellocar.dtos.impl.account.StudentDTOImpl;
import org.hbrs.se2.project.hellocar.util.Globals;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.test.context.SpringBootTest;
import org.testng.annotations.Test;

import java.io.File;
import java.util.concurrent.TimeUnit;

import static org.testng.Assert.*;


public class SeleniumTests {
    // Wegen Einschränkungen aufgrund von nicht beeinflussbarem Shadow-DOM sind einige Tests nicht durchführbar.
    // Jegliche Interaktion mit Textfeldern, außer dem Login-Feld, folglich also
    //  - Erstellung/Bearbeitung eines Accounts
    //  - Erstellung/Bearbeitung eines Stellenangebots
    //  - Bewerbung um eine Stelle

    // Folglich gibt es die Vorraussetzungen:
    // Es existieren Accounts mit Zugangsdaten:
    // Company TestCompany:TestCompany, City = TestCity
    // Student Test:Test, Company Name = TestCompany
    // Die jeweiligen IDs der Accounts müssen eingetragen werden
    // Es existiert mindestens ein beliebiges Jobangebot und eine bewerbung

    private static final String COMPANY_USERNAME = "TestCompany";
    private static final String COMPANY_PASSWORD = "TestCompany";
    private static final int COMPANY_ID = 620;

    private static final String STUDENT_USERNAME = "Test";
    private static final String STUDENT_PASSWORD = "Test";
    private static final int STUDENT_ID = 619;

    // Helferfunktionen
    private static WebElement findElement(WebDriver driver, WebDriverWait wait, String name)
    {
        // Wait for element
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(name)));
        // Find and return
        return driver.findElement(By.xpath(name));
    }

    private static void logIn(WebDriver driver, WebDriverWait wait, JavascriptExecutor js, String username, String password)
    {
        // Lösche cookies und bisherige Sitzung
        driver.manage().deleteAllCookies();

        // Navigiere zur Startseite
        driver.get("http://localhost:8080/");

        // Log in
        findElement(driver, wait, "//input[@name='username']" ).sendKeys(username);
        findElement(driver, wait, "//input[@name='password']" ).sendKeys(password);
        findElement(driver, wait, "//vaadin-button[contains(.,'Log in')]" ).click();
    }

    // Tests
    private static void testLoginFailed(WebDriver driver, WebDriverWait wait, JavascriptExecutor js)
    {
        logIn(driver, wait, js, STUDENT_USERNAME, STUDENT_PASSWORD + "x");

        // Da wir das element nicht einfach so finden und drauf warten können, warten wir 1s
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // Shadow root workaround mit javascript
        WebElement r2 = (WebElement)js.executeScript("return document.querySelector('vaadin-login-form-wrapper').shadowRoot.querySelector('div').querySelector('h5')");
        assert(r2.getText().equals("Incorrect username or password"));

        System.out.println("testLoginFailed passed");
    }

    private static void testLoginSucceeded(WebDriver driver, WebDriverWait wait, JavascriptExecutor js)
    {
        logIn(driver, wait, js, STUDENT_USERNAME, STUDENT_PASSWORD);

        // Assert error message is empty
        WebElement r2 = (WebElement)js.executeScript("return document.querySelector('vaadin-login-form-wrapper').shadowRoot.querySelector('div').querySelector('h5')");
        assert(r2.getText().isEmpty());

        // Search for element when logged in
        try
        {
            WebElement updateAccountLink = findElement(driver, wait, "//a[@id='update-account-link']" );
            System.out.println("testLoginSucceeded passed");
        }
        catch (Exception e)
        {
            System.out.println("testLoginSucceeded failed");
            assert(false);
        }
    }

    private static void testDeleteAccount(WebDriver driver, WebDriverWait wait, JavascriptExecutor js)
    {
        logIn(driver, wait, js, STUDENT_USERNAME, STUDENT_PASSWORD);

        // Click "Update account"
        findElement(driver, wait, "//a[@id='update-account-link']" ).click();

        // Click "delete account"
        findElement(driver, wait, "//vaadin-button[contains(.,'Delete account')]" ).click();

        // Confirm delete
        findElement(driver, wait, "/html/body/vaadin-dialog-overlay/flow-component-renderer/div/vaadin-horizontal-layout[2]/vaadin-button[2]" ).click();

        // Assert we are logged out, wait for the login username field
        findElement(driver, wait, "//input[@name='username']" );

        System.out.println("testDeleteAccount passed");
    }

    // Löscht das erste Stellenangebot
    private static void testDeleteJobAdvertisement(WebDriver driver, WebDriverWait wait, JavascriptExecutor js)
    {
        logIn(driver, wait, js, COMPANY_USERNAME, COMPANY_PASSWORD);

        // Click "Create Job Advertisement"
        findElement(driver, wait, "//a[contains(@href, 'jobs')]" ).click();

        // Warte auf liste, finde erstes Element
        WebElement e = findElement(driver, wait, "//vaadin-button[contains(.,'Update')]" );
        // Scroll nach rechts
        js.executeScript("arguments[0].scrollIntoView(true);", e);

        // Warte auf aktualisierung
        try {
            Thread.sleep(500);
        } catch (InterruptedException ex) {
            ex.printStackTrace();
        }

        // Click "Update"
        e.click();

        // Click "Delete"
        findElement(driver, wait, "//vaadin-button[contains(.,'Delete')]" ).click();

        // Click "Delete" (confirm)
        findElement(driver, wait, "//vaadin-dialog-overlay[@id='overlay']/flow-component-renderer/div/vaadin-horizontal-layout[2]/vaadin-button[2]" ).click();

        System.out.println("testDeleteJobAdvertisement passed");
    }

    private static void testDeleteJobApplication(WebDriver driver, WebDriverWait wait, JavascriptExecutor js)
    {
        logIn(driver, wait, js, COMPANY_USERNAME, COMPANY_PASSWORD);

        // Click "Show Job Application"
        findElement(driver, wait, "//a[contains(@href, 'jobapplications')]" ).click();

        // First item, Click on delete
        findElement(driver, wait, "//vaadin-grid-cell-content[6]/flow-component-renderer/vaadin-button" ).click();

        System.out.println("testDeleteJobApplication passed");
    }

    private static void testViewStudent(WebDriver driver, WebDriverWait wait, JavascriptExecutor js)
    {
        driver.get("http://localhost:8080/viewstudent/" + STUDENT_ID);

        // Wait for fields
        findElement(driver, wait, "//vaadin-text-field" );

        String city = (String)js.executeScript("return document.querySelectorAll('vaadin-text-field')[0].shadowRoot.querySelector('input').value");

        assert(city.equals("TestCity"));

        System.out.println("testViewStudent passed");
    }

    private static void testViewCompany(WebDriver driver, WebDriverWait wait, JavascriptExecutor js)
    {
        driver.get("http://localhost:8080/viewcompany/" + COMPANY_ID);

        // Wait for fields
        findElement(driver, wait, "//vaadin-text-field" );

        String companyName = (String)js.executeScript("return document.querySelectorAll('vaadin-text-field')[0].shadowRoot.querySelector('input').value");

        assert(companyName.equals("TestCompany"));

        System.out.println("testViewCompany passed");
    }

    public static void mainTest()  {

        // WebDriver Settings
        System.setProperty("webdriver.gecko.driver", "C:\\Users\\User\\Desktop\\SE2\\geckodriver.exe");

        // Firefox
        FirefoxOptions o = new FirefoxOptions();
        o.setBinary("C:\\Program Files\\Mozilla Firefox\\firefox.exe");

        WebDriver driver = new FirefoxDriver(o);
        JavascriptExecutor js = (JavascriptExecutor) driver;

        driver.manage().timeouts().pageLoadTimeout(15, TimeUnit.SECONDS);

        WebDriverWait wait = new WebDriverWait( driver, 3 );
        WebDriverWait waitLong = new WebDriverWait( driver, 15 );

        // Warte bis die seite fertig geladen hat und das benutzername feld sichtbar ist
        driver.get("http://localhost:8080/");
        findElement(driver, waitLong, "//input[@name='username']" );

        // Test ohne Account
        testViewStudent(driver, wait, js);
        testViewCompany(driver, wait, js);

        // Test login
        testLoginFailed(driver, wait, js);
        testLoginSucceeded(driver, wait, js);

        // Test delete, allerdings erst nach den anderen tests
        testDeleteJobApplication(driver, wait, js);
        testDeleteJobAdvertisement(driver, wait, js);
        testDeleteAccount(driver, wait, js);

        // Nicht funktionierende Tests aufgrund von Shadow-DOM
        //testCreateAccount(driver, wait, js);
        //testUpdateAccount(driver, wait, js);
        //testCreateJobAdvertisement(driver, wait, js);

        //driver.quit();
    }

    // Nicht funktionierender Code aufgrund von Shadow-DOM
    private static void testCreateAccount(WebDriver driver, WebDriverWait wait, JavascriptExecutor js)
    {
        driver.get("http://localhost:8080/");

        // Click 'Create Account'
        findElement(driver, wait, "//vaadin-button[contains(.,'Create account')]").click();

        // Click 'Student'
        findElement(driver, wait, "//vaadin-button[contains(.,'Student')]").click();

        // Warte bis die Seite fertig geladen hat
        findElement(driver, wait, "//vaadin-text-field[1]" );

        findElement(driver, wait, "//vaadin-text-field[1]" ).sendKeys("Username");

        // Fülle felder aus
        // ((WebElement)js.executeScript("return document.querySelectorAll('vaadin-text-field')[0].shadowRoot.querySelector('input')")).sendKeys("FirstName");
        // Element <input> is not reachable by keyboard, dann halt komplett über javascript

        ((WebElement)js.executeScript("return document.querySelectorAll('vaadin-text-field')[0]")).sendKeys("FirstName");
        //js.executeScript("document.querySelectorAll('vaadin-text-field')[0].shadowRoot.querySelector('input').value = \"" + "FirstName" + "\"");
        js.executeScript("document.querySelectorAll('vaadin-text-field')[1].shadowRoot.querySelector('input').value = \"" + "LastName" + "\"");
        js.executeScript("document.querySelectorAll('vaadin-text-field')[2].shadowRoot.querySelector('input').value = \"" + "UserName" + "\"");
        js.executeScript("document.querySelectorAll('vaadin-email-field')[0].shadowRoot.querySelector('input').value = \"" + "Email" + "\"");
        js.executeScript("document.querySelectorAll('vaadin-select')[0].shadowRoot.querySelector('vaadin-select-text-field').shadowRoot.querySelector('input').value = \"" + "Apache Helicopter" + "\"");
        js.executeScript("document.querySelectorAll('vaadin-password-field')[0].shadowRoot.querySelector('input').value = \"" + "Pass" + "\"");
        js.executeScript("document.querySelectorAll('vaadin-password-field')[1].shadowRoot.querySelector('input').value = \"" + "Pass" + "\""); // ConfirmPass
        js.executeScript("document.querySelectorAll('vaadin-text-field')[3].shadowRoot.querySelector('input').value = \"" + "Street" + "\""); // 3
        js.executeScript("document.querySelectorAll('vaadin-text-field')[4].shadowRoot.querySelector('input').value = \"" + "ZIP" + "\"");
        js.executeScript("document.querySelectorAll('vaadin-text-field')[5].shadowRoot.querySelector('input').value = \"" + "City" + "\""); // Undefined
        js.executeScript("document.querySelectorAll('vaadin-text-field')[6].shadowRoot.querySelector('input').value = \"" + "Street Number" + "\"");
        js.executeScript("document.querySelectorAll('vaadin-date-picker')[0].shadowRoot.querySelector('vaadin-date-picker-text-field').shadowRoot.querySelector('input').value = \"" + "DoB" + "\"");
        js.executeScript("document.querySelectorAll('vaadin-text-field')[7].shadowRoot.querySelector('input').value = \"" + "Study Course" + "\"");
        js.executeScript("document.querySelectorAll('vaadin-text-field')[8].shadowRoot.querySelector('input').value = \"" + "Specialization" + "\"");
        js.executeScript("document.querySelectorAll('vaadin-integer-field')[0].shadowRoot.querySelector('input').value = \"" + "2" + "\""); // Semester
        js.executeScript("document.querySelectorAll('vaadin-text-area')[0].shadowRoot.querySelector('textarea').value = \"" + "Tell us more" + "\"");

        // Click "register"
        findElement(driver, wait, "//vaadin-button[contains(.,'Join us')]").click();
    }
    private static void testUpdateAccount(WebDriver driver, WebDriverWait wait, JavascriptExecutor js)
    {
        logIn(driver, wait, js, STUDENT_USERNAME, STUDENT_PASSWORD);

        driver.get("http://localhost:8080/updatestudent");

        System.out.println("First field: " +  ((WebElement)js.executeScript("return document.querySelectorAll('vaadin-text-field')[0].shadowRoot.querySelector('input')")).getText());

        System.out.println("testUpdateAccount passed");
    }

    private static void testCreateJobAdvertisement(WebDriver driver, WebDriverWait wait, JavascriptExecutor js)
    {
        logIn(driver, wait, js, COMPANY_USERNAME, COMPANY_PASSWORD );

        // Click "Create Job Advertisement"
        findElement(driver, wait, "//a[contains(@href, 'jobadvertisement')]" ).click();

        // Wont work
        findElement(driver, wait, "//vaadin-text-field" ).sendKeys("TITLE");
    }
}
